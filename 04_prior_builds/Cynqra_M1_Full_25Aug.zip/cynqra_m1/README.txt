CYNQRA M1 BUILD KIT
Weeks 0 to 2. Owner: CEO until a CPO exists.
Status: working kit. Not canon. Does not ratify any decision.

WHAT THIS IS

This is the first build surface. It does not replace the Production Build Edition.
It runs the two things the books say can start now:

1. Wizard of Oz validation (Book 4, section 4)
2. Spikes S1, S2, S3 (Book 2, section 10)

It does not start M2. It does not start product design.

CONTENTS

WOZ_RUN.md                 Ten day script, measures, and definition of done
event_log.csv              Event envelope columns from Book 2, section 6
breaks.csv                 Every place the loop breaks
founder_interventions.csv  Counting rule from Book 1, section 6
protocols/                 Blocker, Handoff, Escalation, Approval templates
spikes/s1/                 Runnable objective structuring spike
spikes/S2_BRIEF.md         Coordination cost spike
spikes/S3_BRIEF.md         Verification quality spike
G0_SESSION_CARD.md         What still waits on the ratification session

HOW TO START TODAY

1. Pick one real CRUD style project. D-6 is still Proposed. The books allow
   this category for first runs. Write the project name in WOZ_RUN.md.
2. Open event_log.csv and log from hour one. A spreadsheet is enough.
3. Run S1:
     cd spikes/s1
     python3 run_s1.py
   The harness scores 10 messy objectives against the Book 1 field contract.
   It does not need an API key. If CYNQRA_S1_MODEL_CMD is set, it will call
   that command for the model pass.
4. Book the G0 session. The kit does not wait on it.

HARD RULES DURING THE RUN

- Protocol messages are structured objects, not free chat.
- Event payloads carry no personal data.
- HIGH risk actions need named founder approval.
- One founder intervention is one action the founder takes, excluding reading.
- A failed spike is a successful spike. Write the memo anyway.
