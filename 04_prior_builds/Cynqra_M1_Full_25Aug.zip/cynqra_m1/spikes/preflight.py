#!/usr/bin/env python3
"""What is ready, what is blocked, and what is missing. One screen, no jargon.

Run this first, and run it again whenever you are not sure where you stand.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import model_adapter  # noqa: E402

BAR_S1 = 8
BAR_S3 = 0.8


def line(name, state, detail):
    print(f"{name:<7}{state:<10}{detail}")


def read_json(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def answers_progress():
    folder = HERE / "s1" / "answers"
    if not folder.exists():
        return 0, 0
    corpus = read_json(HERE / "s1" / "corpus.json") or []
    done = sum(
        1
        for c in corpus
        if (folder / f"{c['id']}.txt").exists()
        and (folder / f"{c['id']}.txt").read_text(encoding="utf-8").strip()
    )
    return done, len(corpus)


def main():
    model = model_adapter.resolve()
    blocked = []

    if model is None:
        line("model", "BLOCKED", "No key. Set OPENAI_API_KEY, ANTHROPIC_API_KEY, or CYNQRA_S1_MODEL_CMD.")
        blocked.append("model")
    else:
        tokens = model["tokens"]
        line("model", "READY", f"{model['label']}, tokens {tokens}")

    s1 = read_json(HERE / "s1" / "s1_report.json")
    done, total = answers_progress()
    if s1 and s1.get("passed") is not None:
        verdict = "met bar" if s1.get("met_bar") else "below bar"
        how = "hand carried" if s1.get("source") == "manual_paste" else s1.get("model", "")
        line("S1", "DONE", f"{s1['passed']} of {s1['total']}, bar {BAR_S1}, {verdict}, {how}")
    elif done:
        line("S1", "IN PROG", f"paste pack {done} of {total} answered, then run s1/score_manual.py")
        blocked.append("S1")
    elif model is None:
        line("S1", "BLOCKED", f"needs a key, or run s1/make_paste_pack.py to do it by hand, bar {BAR_S1} of 10")
        blocked.append("S1")
    else:
        line("S1", "READY", f"run s1/run_s1.py, 10 items, bar {BAR_S1} of 10")

    s2 = read_json(HERE / "s2" / "s2_report.json")
    if s2 and s2.get("counts_as_measured_result"):
        verdict = "met bar" if s2.get("met_bar") else "below bar"
        line("S2", "DONE", f"12 tasks, {verdict}, measured tokens")
    elif model is None:
        line("S2", "BLOCKED", "needs a metered key. Cannot be done by hand, it measures cost.")
        blocked.append("S2")
    elif model["tokens"] != "measured":
        line("S2", "BLOCKED", "model found but tokens are estimated. S2 needs an API key to count.")
        blocked.append("S2")
    else:
        line("S2", "READY", "run s2/run_s2.py against the estimate locked 25 Aug")

    s3 = read_json(HERE / "s3" / "s3_report.json")
    if s3:
        verdict = "met bar" if s3.get("met_bar") else "below bar"
        caught = s3.get("caught")
        n = len(caught) if isinstance(caught, list) else caught
        line("S3", "DONE", f"{n} of 10 caught, bar {BAR_S3}, {verdict}, mechanical only")
    else:
        line("S3", "READY", "seeds sealed, run s3/run_s3.py")

    print()
    if blocked:
        print("Blocked:", ", ".join(blocked))
    else:
        print("Nothing blocked.")
    print("An unrun spike is not a failed spike.")
    print("M2 does not start until S1 and S2 have real scores and someone writes the go or no go.")
    print("No key, only a chat subscription? python3 s1/make_paste_pack.py")
    return 0


if __name__ == "__main__":
    sys.exit(main())
