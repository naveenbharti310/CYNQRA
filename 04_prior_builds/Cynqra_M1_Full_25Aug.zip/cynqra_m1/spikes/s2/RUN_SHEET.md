S2 RUN SHEET
Estimate locked: 25 August 2026 in spikes/S2_ESTIMATE.md
Do not edit the estimate after scoring begins.
Do not start this run without a token meter and a model.

Template: CTO, PM, Engineer A, Engineer B.
Project category: CRUD (D-6 ratified).
Minimum: 12 tasks across 3 workstreams.
Every coordination message is a protocol object.

Record per task
task_id, worker, risk_tier, protocol_count, tokens_in, tokens_out, wall_minutes, retries, founder_touched

Pass
Median tokens and wall time within 2x of the matching estimate line.
Protocols stay structured.

This sheet is empty of results until a scored run exists.
