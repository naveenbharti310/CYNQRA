SANDBOX RESET, 25 AUGUST 2026

What happened
The working sandbox was wiped during the session. Every file under /data was
gone except four scripts written moments before.

What was lost from the sandbox
- run 002 event log and measures
- the canon zip v1.2 build inputs
- the G0 results json
- the kit files protocol.py, events.py, verify.py, test_kit.py
- the S3 report json and the S1 and S2 memo files
- the original wording of S1 corpus items T07 to T10

What was not lost
- The Notion canon: Books 0 to 4, the Decision Log, the M1 kit page.
- Every file already downloaded to the founder: the v1.2 zip, the run 002
  board, close and audit pages, the G0 sheets, the S3 memo, the counsel draft.
- The sealed S3 seed list and the S2 estimate, both restored word for word
  from the session record.

What was rebuilt, and how honestly
- Restored verbatim: S2_ESTIMATE.md, s2/tasks.json, s3/seeds.json,
  kit/contract_checks.py, s3/run_s3.py, s3/tainted fixtures, model_adapter.py.
- Rewritten because the original text is gone: s1/prompt.txt, and S1 corpus
  items T07 to T10. Each corpus item now carries a provenance field so nobody
  later mistakes a rewrite for the original.
- S3 was rerun after the restore to prove the score reproduces.

The lesson worth keeping
Nothing that matters may live only in a sandbox. From the first engineer
hire, the spike harness, the seeds, the estimates and the event logs go in a
git repo, and every scored run exports a zip the same day. This is the same
rule the canon already puts on customer exports, applied to ourselves.
