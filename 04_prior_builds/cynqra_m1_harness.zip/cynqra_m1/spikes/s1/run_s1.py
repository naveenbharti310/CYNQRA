#!/usr/bin/env python3
"""S1: can a model turn a messy founder objective into the Book 1 schema?

Success: 8 of 10 structured correctly, one retry allowed.
This harness does not invent fields. Missing fields must be listed.

With no model it runs a deterministic baseline so the pipeline can be proven.
That baseline is not the spike result.
Set OPENAI_API_KEY, ANTHROPIC_API_KEY, or CYNQRA_S1_MODEL_CMD.
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import model_adapter

USAGE = {"calls": 0, "tokens_in": 0, "tokens_out": 0, "estimated": False, "errors": []}

FIELDS = [
    "product",
    "target_customer",
    "primary_outcome",
    "business_outcome",
    "success_criteria",
    "constraints",
    "priorities",
]


def load_corpus():
    return json.loads((HERE / "corpus.json").read_text(encoding="utf-8"))


def normalize(text):
    return re.sub(r"[^a-z0-9 ]+", " ", (text or "").lower()).split()


def parse_json(raw):
    raw = (raw or "").strip()
    if not raw:
        return None
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", raw, re.S)
        if not match:
            return None
        try:
            return json.loads(match.group(0))
        except json.JSONDecodeError:
            return None


def empty_result():
    out = {k: "" for k in FIELDS}
    out["missing_fields"] = list(FIELDS)
    return out


def baseline(messy):
    """Deterministic filler so the scorer can run with no model.
    It copies short clauses. It is not a model and must not be reported
    as the S1 result.
    """
    text = messy.strip()
    sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", text) if s.strip()]
    first = sentences[0] if sentences else text
    last = sentences[-1] if sentences else text
    out = {
        "product": first[:120],
        "target_customer": "",
        "primary_outcome": first[:160],
        "business_outcome": last[:160],
        "success_criteria": "",
        "constraints": "",
        "priorities": "",
        "missing_fields": [],
    }
    lower = text.lower()
    if "no " in lower or "not " in lower or "don't" in lower or "do not" in lower:
        out["constraints"] = last[:160]
    for key in FIELDS:
        if not out[key]:
            out["missing_fields"].append(key)
    return out


def call_model(prompt):
    if model_adapter.resolve() is None:
        return None
    out = model_adapter.complete(prompt)
    USAGE["calls"] += 1
    USAGE["tokens_in"] += out["tokens_in"]
    USAGE["tokens_out"] += out["tokens_out"]
    if out["estimated"]:
        USAGE["estimated"] = True
    if out.get("error"):
        USAGE["errors"].append(out["error"])
    return parse_json(out["text"])


def complete(obj):
    out = empty_result()
    if not isinstance(obj, dict):
        return out
    missing = []
    for key in FIELDS:
        val = obj.get(key)
        out[key] = val.strip() if isinstance(val, str) else ""
        if not out[key]:
            missing.append(key)
    listed = obj.get("missing_fields") or []
    if isinstance(listed, list):
        extra = [x for x in listed if isinstance(x, str)]
        out["missing_fields"] = sorted(set(missing + extra))
    else:
        out["missing_fields"] = missing
    return out


def overlap(pred, gold):
    pw, gw = set(normalize(pred)), set(normalize(gold))
    if not gw:
        return 1.0 if not pw else 0.0
    if not pw:
        return 0.0
    return len(pw & gw) / len(gw)


def score_one(pred, gold):
    pred = complete(pred)
    present = all(pred[k] for k in FIELDS)
    hits = {k: overlap(pred[k], gold[k]) for k in FIELDS}
    strong = sum(1 for v in hits.values() if v >= 0.5)
    passed = present and strong >= 4
    return {
        "passed": passed,
        "present": present,
        "strong_fields": strong,
        "overlaps": hits,
        "pred": pred,
    }


def prompt_for(messy, retry=False):
    base = (HERE / "prompt.txt").read_text(encoding="utf-8")
    extra = ""
    if retry:
        extra = (
            "\nRetry. Fill every field you can from the text. "
            "Do not invent facts that are not in the objective.\n"
        )
    return extra + base + messy + "\n"


def run_case(case, use_model):
    messy = case["messy"]
    gold = case["gold"]
    attempts = []
    source = "model" if use_model else "baseline"
    pred = None
    for attempt in (1, 2):
        if use_model:
            raw = call_model(prompt_for(messy, retry=attempt == 2))
            pred = complete(raw)
        else:
            pred = baseline(messy) if attempt == 1 else complete(pred)
        result = score_one(pred, gold)
        result["attempt"] = attempt
        result["source"] = source
        attempts.append(result)
        if result["passed"]:
            break
    final = attempts[-1]
    final["id"] = case["id"]
    final["attempts"] = len(attempts)
    return final


def main():
    corpus = load_corpus()
    model = model_adapter.resolve()
    use_model = model is not None
    rows = [run_case(case, use_model) for case in corpus]
    passed = sum(1 for r in rows if r["passed"])
    report = {
        "spike": "S1",
        "source": "model" if use_model else "baseline",
        "model": model["label"] if use_model else None,
        "passed": passed,
        "total": len(rows),
        "success_bar": 8,
        "met_bar": passed >= 8,
        "usage": dict(USAGE),
        "note": (
            "Baseline only. Not the spike result. Set a model key or CYNQRA_S1_MODEL_CMD."
            if not use_model
            else "Model pass. This is the spike result."
        ),
        "cases": [
            {
                "id": r["id"],
                "passed": r["passed"],
                "attempts": r["attempts"],
                "strong_fields": r["strong_fields"],
                "present": r["present"],
            }
            for r in rows
        ],
    }
    out = HERE / "s1_report.json"
    out.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: report[k] for k in ("source", "model", "passed", "total", "met_bar", "usage", "note")}, indent=2))
    print("wrote", out)
    if not use_model:
        print("S1 not scored as a model spike. Baseline only.")
        return 0
    return 0 if report["met_bar"] else 1


if __name__ == "__main__":
    sys.exit(main())
