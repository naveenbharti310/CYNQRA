#!/usr/bin/env python3
"""Says exactly what is ready and what is missing. Changes nothing."""
from __future__ import annotations

import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import model_adapter


def main() -> int:
    model = model_adapter.resolve()
    lines = []

    if model is None:
        lines.append(("model", "BLOCKED", "No model. Set OPENAI_API_KEY, ANTHROPIC_API_KEY, or CYNQRA_S1_MODEL_CMD."))
    else:
        lines.append(("model", "READY", f"{model['label']} via {model['kind']}, tokens {model['tokens']}"))

    corpus = HERE / "s1" / "corpus.json"
    n = len(json.loads(corpus.read_text(encoding="utf-8"))) if corpus.exists() else 0
    lines.append(("S1", "READY" if model and n == 10 else "BLOCKED", f"{n} objectives, bar 8 of 10" + ("" if model else ", needs a model")))

    est = HERE / "S2_ESTIMATE.md"
    tasks = HERE / "s2" / "tasks.json"
    ok2 = est.exists() and tasks.exists() and model is not None
    detail2 = []
    if not est.exists():
        detail2.append("estimate missing")
    if not tasks.exists():
        detail2.append("task set missing")
    if model is None:
        detail2.append("needs a model")
    if model and model["tokens"] == "estimated":
        detail2.append("tokens would be estimated, not measured")
    if not detail2:
        detail2.append("12 tasks, estimate locked")
    lines.append(("S2", "READY" if ok2 else "BLOCKED", ", ".join(detail2)))

    seeds = HERE / "s3" / "seeds.json"
    rep = HERE / "s3" / "s3_report.json"
    if rep.exists():
        r = json.loads(rep.read_text(encoding="utf-8"))
        lines.append(("S3", "DONE", f"{len(r['caught'])} of {r['seeded']} caught, bar {r['bar']}, mechanical only"))
    else:
        lines.append(("S3", "READY" if seeds.exists() else "BLOCKED", "seeds sealed" if seeds.exists() else "no seeds"))

    width = max(len(a) for a, _, _ in lines)
    for name, status, detail in lines:
        print(f"{name.ljust(width)}  {status.ljust(8)}  {detail}")

    blocked = [n for n, s, _ in lines if s == "BLOCKED"]
    print()
    if blocked:
        print("Blocked: " + ", ".join(blocked))
        print("An unrun spike is not a failed spike.")
    else:
        print("All clear. Run s1/run_s1.py then s2/run_s2.py.")
    print("M2 does not start until S1 and S2 have real scores.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
