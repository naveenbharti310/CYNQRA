S2 RUN SHEET
Estimate locked: 25 August 2026 in spikes/S2_ESTIMATE.md
Do not edit the estimate after scoring begins.
Do not start this run without a token meter and a model.

Template: CTO, PM, Engineer A, Engineer B.
Project category: CRUD (D-6 ratified).
Minimum: 12 tasks across 3 workstreams. See s2/tasks.json.
Every coordination message is a protocol object.

Record per task
task_id, worker, risk_tier, protocol_count, tokens_in, tokens_out, wall_minutes, retries, founder_touched

Pass
Median tokens and wall time within 2x of the matching estimate line.
Protocols stay structured.

Honesty rule
A token count estimated from characters is not a measured result. The runner
marks this as counts_as_measured_result false. Use an API key if the number
is meant to count.

This sheet is empty of results until a scored run exists.
