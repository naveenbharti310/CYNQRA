#!/usr/bin/env python3
"""S2: what does coordination actually cost?

Twelve tasks, four workers, protocol objects only. No free chat.
Refuses to score without a model. Refuses to call estimated tokens measured.
"""
from __future__ import annotations

import json
import re
import statistics
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
SPIKES = HERE.parent
sys.path.insert(0, str(SPIKES))
import model_adapter

ESTIMATE_FILE = SPIKES / "S2_ESTIMATE.md"

WORKER_ROLE = {
    "w_cto": "You are the CTO worker. You review and decide. You do not write product copy.",
    "w_pm": "You are the PM worker. You write specs and acceptance checks. You do not write code.",
    "w_eng_a": "You are Engineer A. You write Python and tests.",
    "w_eng_b": "You are Engineer B. You write Python and tests.",
}


def parse_estimate(text: str) -> dict:
    def grab(pattern: str) -> float | None:
        m = re.search(pattern, text, re.I)
        if not m:
            return None
        return float(m.group(1).replace(",", ""))

    return {
        "tokens_low": grab(r"Tokens per LOW risk task:\s*([\d,]+)"),
        "tokens_medium": grab(r"Tokens per MEDIUM risk task:\s*([\d,]+)"),
        "tokens_message": grab(r"Tokens per protocol message:\s*([\d,]+)"),
        "minutes_low": grab(r"Wall minutes per LOW task:\s*([\d,]+)"),
        "minutes_medium": grab(r"Wall minutes per MEDIUM task:\s*([\d,]+)"),
    }


def protocol_object(kind: str, sender: str, recipient: str, body: dict, seq: int) -> dict:
    return {
        "protocol_version": "1.0",
        "type": kind,
        "seq": seq,
        "sender": sender,
        "recipient": recipient,
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "correlation_id": body.get("task_id", ""),
        "body": body,
    }


def prompt_for(task: dict, objective: str) -> str:
    return (
        WORKER_ROLE[task["owner"]]
        + "\n\nObjective: "
        + objective
        + "\n\nYou receive one protocol object and you return one protocol object.\n"
        "Return only JSON with these keys: type set to task.result, task_id, status "
        "set to done or blocked, output, assumptions as a list, blockers as a list.\n"
        "Do not invent requirements. Do not add a public site or an applicant login.\n\n"
        "Assignment:\n"
        + json.dumps({"task_id": task["id"], "risk": task["risk"], "ask": task["ask"]}, indent=2)
        + "\n"
    )


def parse_json(raw: str):
    raw = (raw or "").strip()
    if not raw:
        return None
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", raw, re.S)
        if not m:
            return None
        try:
            return json.loads(m.group(0))
        except json.JSONDecodeError:
            return None


def main() -> int:
    model = model_adapter.resolve()
    if model is None:
        print(
            json.dumps(
                {
                    "spike": "S2",
                    "scored": False,
                    "reason": "No model. Set CYNQRA_S1_MODEL_CMD, OPENAI_API_KEY, or ANTHROPIC_API_KEY.",
                    "note": "An unrun spike is not a failed spike.",
                },
                indent=2,
            )
        )
        return 2

    if not ESTIMATE_FILE.exists():
        print("S2_ESTIMATE.md is missing. The estimate must exist before scoring.")
        return 2

    estimate = parse_estimate(ESTIMATE_FILE.read_text(encoding="utf-8"))
    plan = json.loads((HERE / "tasks.json").read_text(encoding="utf-8"))
    objective = plan["objective"]

    rows = []
    messages = []
    seq = 0
    for ws in plan["workstreams"]:
        for task in ws["tasks"]:
            seq += 1
            assign = protocol_object(
                "task.assign",
                "orchestrator",
                task["owner"],
                {"task_id": task["id"], "risk": task["risk"], "ask": task["ask"]},
                seq,
            )
            messages.append(assign)
            started = time.time()
            out = model_adapter.complete(prompt_for(task, objective))
            parsed = parse_json(out["text"])
            structured = isinstance(parsed, dict) and parsed.get("type") == "task.result"
            seq += 1
            result = protocol_object(
                "task.result",
                task["owner"],
                "orchestrator",
                parsed if isinstance(parsed, dict) else {"task_id": task["id"], "status": "unparsed"},
                seq,
            )
            messages.append(result)
            rows.append(
                {
                    "task_id": task["id"],
                    "workstream": ws["id"],
                    "owner": task["owner"],
                    "risk": task["risk"],
                    "protocol_count": 2,
                    "tokens_in": out["tokens_in"],
                    "tokens_out": out["tokens_out"],
                    "tokens_total": out["tokens_in"] + out["tokens_out"],
                    "wall_minutes": round((time.time() - started) / 60.0, 3),
                    "structured": structured,
                    "error": out.get("error"),
                    "estimated_tokens": out["estimated"],
                }
            )

    def median(vals):
        return round(statistics.median(vals), 2) if vals else None

    low = [r for r in rows if r["risk"] == "LOW"]
    med = [r for r in rows if r["risk"] == "MEDIUM"]
    estimated_any = any(r["estimated_tokens"] for r in rows)
    errors = [r["task_id"] for r in rows if r["error"]]

    measured = {
        "tokens_low": median([r["tokens_total"] for r in low]),
        "tokens_medium": median([r["tokens_total"] for r in med]),
        "minutes_low": median([r["wall_minutes"] for r in low]),
        "minutes_medium": median([r["wall_minutes"] for r in med]),
    }

    def within_2x(actual, target):
        if actual is None or target is None:
            return None
        return actual <= target * 2

    checks = {k: within_2x(measured[k], estimate.get(k)) for k in measured}
    all_structured = all(r["structured"] for r in rows)
    decided = [v for v in checks.values() if v is not None]
    met_bar = bool(decided) and all(decided) and all_structured and not errors

    report = {
        "spike": "S2",
        "scored": True,
        "model": model["label"],
        "token_source": "estimated" if estimated_any else "measured",
        "tasks": len(rows),
        "protocol_messages": len(messages),
        "all_messages_structured": all_structured,
        "errors": errors,
        "estimate": estimate,
        "measured_median": measured,
        "within_2x": checks,
        "met_bar": met_bar,
        "counts_as_measured_result": (not estimated_any) and not errors,
        "note": (
            "Token counts are estimated from characters. Not a measured S2 result."
            if estimated_any
            else "Token counts came from the model API."
        ),
        "rows": rows,
    }
    (HERE / "s2_report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    (HERE / "s2_messages.json").write_text(json.dumps(messages, indent=2) + "\n", encoding="utf-8")
    summary = {k: report[k] for k in ("model", "token_source", "tasks", "measured_median", "within_2x", "met_bar", "counts_as_measured_result", "errors")}
    print(json.dumps(summary, indent=2))
    return 0 if met_bar else 1


if __name__ == "__main__":
    sys.exit(main())
