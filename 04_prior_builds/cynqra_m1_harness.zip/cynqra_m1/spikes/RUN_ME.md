HOW TO RUN THE SPIKES
Written 25 August 2026. For the founder or the first engineer.

What you need
One of these, set in the shell before running:

  export OPENAI_API_KEY=sk-...
  export ANTHROPIC_API_KEY=sk-ant-...

Or a command of your own that reads a prompt on stdin and prints text on stdout:

  export CYNQRA_S1_MODEL_CMD='my-model-cli --quiet'

Optional: pick the model.

  export CYNQRA_MODEL=gpt-4o-mini

Step 1. Check what is ready

  python3 spikes/preflight.py

It prints one line per spike: ready or blocked, and what is missing.

Step 2. Run S1

  python3 spikes/s1/run_s1.py

Ten messy objectives into seven fields. Bar: 8 of 10, one retry allowed.
Writes s1/s1_report.json.

Step 3. Run S2

  python3 spikes/s2/run_s2.py

Twelve tasks, four workers, protocol objects only. Compares the measured
median against the estimate locked on 25 August.
Writes s2/s2_report.json and s2/s2_messages.json.

Step 4. Run S3

  python3 spikes/s3/run_s3.py

Mechanical only. Already reproduced at 9 of 10.

Rules that keep the result honest
1. Do not edit s3/seeds.json after scoring starts.
2. Do not edit S2_ESTIMATE.md after scoring starts.
3. An estimated token count from CYNQRA_S1_MODEL_CMD is not a measured S2
   result. Use an API key if you want the S2 token number to count.
4. A run with no model is not a failed spike. It is an unrun spike.
5. stub_model.sh is a wiring test. It is not a model and its output is never
   a spike result.
6. M2 does not start until S1 and S2 have real scores and someone writes
   the go or no go.

Where this lives
This folder is the only copy unless you keep the zip. A sandbox is not
storage. Put this in a git repo on day one of the engineer hire.
