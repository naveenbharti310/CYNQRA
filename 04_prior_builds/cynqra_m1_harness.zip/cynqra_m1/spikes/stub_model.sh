#!/bin/sh
# Wiring test only. Not a model. Not an S1 result.
# Reads a prompt on stdin, ignores it, prints one fixed partial answer.
cat > /dev/null
cat <<'JSON'
{
  "product": "a tool",
  "target_customer": "",
  "primary_outcome": "do the thing",
  "business_outcome": "",
  "success_criteria": "",
  "constraints": "",
  "priorities": "",
  "missing_fields": ["target_customer", "business_outcome", "success_criteria", "constraints", "priorities"]
}
JSON
